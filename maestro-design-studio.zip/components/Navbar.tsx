'use client';

import React from 'react';
import { Language, Currency } from '@/types/store';
import { translations, currencySymbols } from '@/lib/i18n';
import { ShoppingBag, Lock, Sparkles, Menu, X, ChevronDown } from 'lucide-react';

interface NavbarProps {
  language: Language;
  setLanguage: (lang: Language) => void;
  currency: Currency;
  setCurrency: (curr: Currency) => void;
  cartCount: number;
  onOpenCart: () => void;
  onOpenAdmin: () => void;
  storeName: string;
}

export const Navbar: React.FC<NavbarProps> = ({
  language,
  setLanguage,
  currency,
  setCurrency,
  cartCount,
  onOpenCart,
  onOpenAdmin,
  storeName,
}) => {
  const t = translations[language];
  const [mobileMenuOpen, setMobileMenuOpen] = React.useState(false);
  const [langDropdownOpen, setLangDropdownOpen] = React.useState(false);
  const [currencyDropdownOpen, setCurrencyDropdownOpen] = React.useState(false);

  const isRtl = language === 'ar';

  const scrollToSection = (id: string) => {
    setMobileMenuOpen(false);
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <header className="sticky top-0 z-40 w-full bg-[#0A0A0A]/90 border-b border-white/10 backdrop-blur-xl">
      {/* Top Banner with Motto and Quick Settings */}
      <div className="bg-[#080808] border-b border-white/10 px-4 py-1.5 text-xs text-gray-300 flex flex-wrap justify-between items-center max-w-7xl mx-auto">
        <div className="flex items-center gap-2 font-medium">
          <Sparkles className="w-3.5 h-3.5 text-amber-500 animate-pulse" />
          <span className="text-gray-300">{t.motto}</span>
        </div>

        <div className="flex items-center gap-4">
          {/* Language Selector */}
          <div className="relative">
            <button
              onClick={() => setLangDropdownOpen(!langDropdownOpen)}
              className="flex items-center gap-1.5 px-3 py-1 rounded-full bg-white/5 border border-white/10 hover:bg-white/10 text-[11px] text-gray-200 transition-colors"
            >
              <span>
                {language === 'ar' ? '🇸🇦 العربية' : language === 'en' ? '🇬🇧 English' : '🇫🇷 Français'}
              </span>
              <ChevronDown className="w-3 h-3 text-amber-500" />
            </button>

            {langDropdownOpen && (
              <div className="absolute right-0 mt-1 w-32 bg-[#0C0C0C] border border-white/10 rounded-xl shadow-2xl py-1 z-50">
                <button
                  onClick={() => { setLanguage('ar'); setLangDropdownOpen(false); }}
                  className={`w-full text-right px-3 py-1.5 text-xs hover:bg-white/10 flex items-center gap-2 ${language === 'ar' ? 'text-amber-500 font-bold' : 'text-gray-300'}`}
                >
                  🇸🇦 العربية
                </button>
                <button
                  onClick={() => { setLanguage('en'); setLangDropdownOpen(false); }}
                  className={`w-full text-left px-3 py-1.5 text-xs hover:bg-white/10 flex items-center gap-2 ${language === 'en' ? 'text-amber-500 font-bold' : 'text-gray-300'}`}
                >
                  🇬🇧 English
                </button>
                <button
                  onClick={() => { setLanguage('fr'); setLangDropdownOpen(false); }}
                  className={`w-full text-left px-3 py-1.5 text-xs hover:bg-white/10 flex items-center gap-2 ${language === 'fr' ? 'text-amber-500 font-bold' : 'text-gray-300'}`}
                >
                  🇫🇷 Français
                </button>
              </div>
            )}
          </div>

          <span className="opacity-30">|</span>

          {/* Currency Selector */}
          <div className="relative flex items-center gap-1">
            <span className="text-gray-400 hidden sm:inline text-xs">{t.currencyLabel}</span>
            <button
              onClick={() => setCurrencyDropdownOpen(!currencyDropdownOpen)}
              className="flex items-center gap-1 px-3 py-1 rounded-full bg-white/5 border border-white/10 hover:bg-white/10 text-[11px] font-bold text-amber-500 transition-colors"
            >
              <span>{currency} ({currencySymbols[currency]})</span>
              <ChevronDown className="w-3 h-3 text-amber-500" />
            </button>

            {currencyDropdownOpen && (
              <div className="absolute right-0 mt-1 w-28 bg-[#0C0C0C] border border-white/10 rounded-xl shadow-2xl py-1 z-50">
                {(['SAR', 'USD', 'EUR', 'AED', 'TND'] as Currency[]).map((c) => (
                  <button
                    key={c}
                    onClick={() => { setCurrency(c); setCurrencyDropdownOpen(false); }}
                    className={`w-full text-center px-3 py-1.5 text-xs hover:bg-white/10 flex justify-between items-center ${currency === c ? 'text-amber-500 font-bold' : 'text-gray-300'}`}
                  >
                    <span>{c}</span>
                    <span>{currencySymbols[c]}</span>
                  </button>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Main Navigation Bar */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-3.5 flex items-center justify-between">
        {/* Brand Logo */}
        <div 
          onClick={() => scrollToSection('hero')}
          className="cursor-pointer flex items-center gap-3 group"
        >
          <div className="w-10 h-10 rounded-xl bg-amber-500 p-0.5 shadow-lg shadow-amber-500/10 group-hover:scale-105 transition-transform">
            <div className="w-full h-full bg-[#0A0A0A] rounded-[10px] flex items-center justify-center">
              <span className="font-serif italic font-bold text-xl text-amber-500">M</span>
            </div>
          </div>
          <div className="flex flex-col">
            <span className="font-serif italic font-bold text-xl tracking-widest text-amber-500 uppercase">
              MAESTRO
            </span>
            <span className="text-[10px] tracking-[0.3em] uppercase opacity-50 font-sans -mt-1">
              Design Studio
            </span>
          </div>
        </div>

        {/* Desktop Nav Links */}
        <nav className="hidden lg:flex items-center gap-8 text-xs font-medium uppercase tracking-wider text-gray-300">
          <button onClick={() => scrollToSection('hero')} className="hover:text-amber-500 transition-colors">
            {t.navHome}
          </button>
          <button onClick={() => scrollToSection('services')} className="hover:text-amber-500 transition-colors">
            {t.navServices}
          </button>
          <button onClick={() => scrollToSection('portfolio')} className="hover:text-amber-500 transition-colors">
            {t.navPortfolio}
          </button>
          <button onClick={() => scrollToSection('coupons')} className="hover:text-amber-500 transition-colors flex items-center gap-1 text-amber-500 font-semibold">
            <span>🎁</span>
            <span>{t.navCoupons}</span>
          </button>
          <button onClick={() => scrollToSection('contact')} className="hover:text-amber-500 transition-colors">
            {t.navContact}
          </button>
        </nav>

        {/* Action Controls */}
        <div className="flex items-center gap-3">
          {/* Cart Button */}
          <button
            onClick={onOpenCart}
            id="open-cart-button"
            className="relative px-3.5 py-2 rounded-xl bg-white/5 border border-white/10 hover:border-amber-500/50 hover:bg-white/10 text-gray-200 flex items-center gap-2 transition-all hover:scale-105 active:scale-95"
            title={t.cartTitle}
          >
            <ShoppingBag className="w-4 h-4 text-amber-500" />
            <span className="font-bold text-xs">{cartCount}</span>
            {cartCount > 0 && (
              <span className="absolute -top-1 -right-1 w-4 h-4 rounded-full bg-amber-500 text-black font-extrabold text-[9px] flex items-center justify-center shadow-lg">
                {cartCount}
              </span>
            )}
          </button>

          {/* Secret Admin Panel Button */}
          <button
            onClick={onOpenAdmin}
            id="open-admin-button"
            className="p-2 rounded-xl bg-white/5 border border-white/10 text-gray-400 hover:text-amber-500 hover:border-amber-500/40 hover:bg-white/10 transition-all"
            title={t.adminTitle}
          >
            <Lock className="w-4 h-4" />
          </button>

          {/* Mobile Menu Toggle */}
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="p-2 lg:hidden rounded-lg bg-white/5 border border-white/10 text-gray-300 hover:text-amber-500"
          >
            {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>
      </div>

      {/* Mobile Drawer */}
      {mobileMenuOpen && (
        <div className="lg:hidden border-t border-amber-500/20 bg-[#0c0e17]/95 backdrop-blur-2xl px-6 py-6 flex flex-col gap-4 text-base font-medium">
          <button
            onClick={() => scrollToSection('hero')}
            className="text-right py-2 hover:text-amber-300 border-b border-gray-800"
          >
            {t.navHome}
          </button>
          <button
            onClick={() => scrollToSection('services')}
            className="text-right py-2 hover:text-amber-300 border-b border-gray-800"
          >
            {t.navServices}
          </button>
          <button
            onClick={() => scrollToSection('portfolio')}
            className="text-right py-2 hover:text-amber-300 border-b border-gray-800"
          >
            {t.navPortfolio}
          </button>
          <button
            onClick={() => scrollToSection('coupons')}
            className="text-right py-2 hover:text-amber-300 border-b border-gray-800 flex items-center justify-end gap-2"
          >
            <span>{t.navCoupons}</span>
            <span>🎁</span>
          </button>
          <button
            onClick={() => scrollToSection('contact')}
            className="text-right py-2 hover:text-amber-300 border-b border-gray-800"
          >
            {t.navContact}
          </button>
        </div>
      )}
    </header>
  );
};
