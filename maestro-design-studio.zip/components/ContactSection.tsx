'use client';

import React from 'react';
import { StoreSettings, Language } from '@/types/store';
import { translations } from '@/lib/i18n';
import { MessageCircle, Smartphone, Ghost, ExternalLink } from 'lucide-react';

interface ContactSectionProps {
  settings: StoreSettings;
  language: Language;
}

export const ContactSection: React.FC<ContactSectionProps> = ({ settings, language }) => {
  const t = translations[language];

  const cleanNum = settings.whatsappNumber.replace(/[^0-9]/g, '');

  return (
    <section id="contact" className="py-16 px-4 max-w-6xl mx-auto">
      <div className="text-center space-y-4 mb-12">
        <h2 className="text-3xl sm:text-5xl font-serif italic text-white">
          تواصل <span className="text-amber-500">مع الاستوديو</span>
        </h2>
        <p className="text-gray-400 text-xs sm:text-sm">
          نحن هنا لتحويل رؤيتك إلى هوية بصرية مبهرة. اختر المنصة المفضلة لديك للتواصل.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 max-w-3xl mx-auto">
        {/* WhatsApp Direct */}
        <a
          href={`https://wa.me/${cleanNum}`}
          target="_blank"
          rel="noopener noreferrer"
          className="bg-green-600/10 border border-green-600/20 p-8 rounded-xl flex flex-col items-center text-center gap-3 hover:bg-green-600/20 transition-all group"
        >
          <div className="text-4xl">💬</div>
          <div>
            <h3 className="text-lg font-semibold text-white group-hover:text-emerald-400 transition-colors">
              {t.whatsapp}
            </h3>
            <p className="text-xs text-gray-400 mt-1">{t.whatsappDesc}</p>
            <span className="inline-flex items-center gap-1.5 text-xs font-bold text-emerald-400 mt-4 px-4 py-2 rounded-lg bg-emerald-500/10 border border-emerald-500/20">
              <span>تواصل مباشر عبر الواتساب</span>
              <ExternalLink className="w-3.5 h-3.5" />
            </span>
          </div>
        </a>

        {/* TopTop KSA */}
        <div className="bg-amber-600/10 border border-amber-600/20 p-8 rounded-xl flex flex-col items-center text-center gap-3 hover:bg-amber-600/20 transition-all group">
          <div className="text-4xl">📱</div>
          <div>
            <h3 className="text-lg font-semibold text-white group-hover:text-amber-400 transition-colors">
              {t.toptopKsa}
            </h3>
            <p className="text-xs text-gray-400 mt-1">{t.toptopKsaDesc}</p>
            <span className="inline-flex items-center gap-1.5 text-xs font-mono font-bold text-amber-500 mt-4 px-4 py-2 rounded-lg bg-amber-500/10 border border-amber-500/20">
              ID: 25859934
            </span>
          </div>
        </div>
      </div>
    </section>
  );
};
