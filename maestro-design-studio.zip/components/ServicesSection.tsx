'use client';

import React, { useState } from 'react';
import { ServiceItem, Language, Currency } from '@/types/store';
import { translations, currencySymbols } from '@/lib/i18n';
import { ShoppingCart, Check, Clock, Sparkles, Plus, Info } from 'lucide-react';

interface ServicesSectionProps {
  services: ServiceItem[];
  language: Language;
  currency: Currency;
  sarConversionRates: Record<Currency, number>;
  onAddToCart: (service: ServiceItem, customNotes?: string) => void;
}

export const ServicesSection: React.FC<ServicesSectionProps> = ({
  services,
  language,
  currency,
  sarConversionRates,
  onAddToCart,
}) => {
  const t = translations[language];
  const [selectedService, setSelectedService] = useState<ServiceItem | null>(null);
  const [customBrief, setCustomBrief] = useState('');
  const [addedAnimationId, setAddedAnimationId] = useState<string | null>(null);

  const getPrice = (priceSAR: number) => {
    const rate = sarConversionRates[currency] || 1;
    const converted = Math.round(priceSAR * rate);
    return `${converted} ${currencySymbols[currency]}`;
  };

  const handleAddClick = (service: ServiceItem) => {
    onAddToCart(service, customBrief);
    setAddedAnimationId(service.id);
    setTimeout(() => setAddedAnimationId(null), 1500);
    setSelectedService(null);
    setCustomBrief('');
  };

  return (
    <section id="services" className="py-20 px-4 max-w-7xl mx-auto relative">
      {/* Section Header */}
      <div className="text-center max-w-3xl mx-auto mb-16 space-y-4">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white/5 border border-white/10 text-amber-500 text-xs font-semibold">
          <Sparkles className="w-3.5 h-3.5 text-amber-500" />
          <span>{t.servicesTitle}</span>
        </div>
        <h2 className="text-3xl sm:text-5xl font-serif italic text-white tracking-tight">
          خدمات <span className="text-amber-500">التصميم والابتكار</span>
        </h2>
        <p className="text-gray-400 text-sm sm:text-base">
          {t.servicesSubtitle}
        </p>
      </div>

      {/* Services Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {services.map((service) => {
          const serviceName =
            language === 'en' && service.nameEn
              ? service.nameEn
              : language === 'fr' && service.nameFr
              ? service.nameFr
              : service.name;

          const serviceDesc =
            language === 'en' && service.descriptionEn
              ? service.descriptionEn
              : language === 'fr' && service.descriptionFr
              ? service.descriptionFr
              : service.description;

          const isJustAdded = addedAnimationId === service.id;

          return (
            <div
              key={service.id}
              className={`group relative bg-white/5 border border-white/5 p-6 rounded-xl hover:bg-white/10 transition-all flex flex-col justify-between ${
                service.popular ? 'border-amber-500/40 bg-white/[0.07]' : ''
              }`}
            >
              {/* Popular Tag */}
              {service.popular && (
                <div className="absolute -top-3 left-6 px-3 py-0.5 rounded-full bg-amber-500 text-black font-bold text-[10px] uppercase tracking-wider shadow-md">
                  الأكثر طلباً ⭐
                </div>
              )}

              {/* Service Header */}
              <div>
                <div className="flex items-start justify-between gap-4 mb-4">
                  <div className="text-3xl p-2 rounded-lg bg-white/5 border border-white/5">
                    {service.emoji}
                  </div>
                  <div className="text-left flex flex-col items-end">
                    <span className="text-xl font-mono font-bold text-amber-500">
                      {getPrice(service.priceSAR)}
                    </span>
                    {currency !== 'SAR' && (
                      <span className="text-[10px] text-gray-400 font-mono">
                        ({service.priceSAR} ر.س)
                      </span>
                    )}
                  </div>
                </div>

                <h3 className="text-base font-semibold text-white mb-2 group-hover:text-amber-500 transition-colors">
                  {serviceName}
                </h3>

                <p className="text-gray-400 text-xs leading-relaxed mb-6 font-light">
                  {serviceDesc}
                </p>
              </div>

              {/* Delivery and Action */}
              <div className="pt-4 border-t border-white/5 space-y-4">
                {service.deliveryDays && (
                  <div className="flex items-center gap-1.5 text-xs text-gray-400">
                    <Clock className="w-3.5 h-3.5 text-amber-500" />
                    <span>
                      {t.deliveryIn} {service.deliveryDays} {t.days}
                    </span>
                  </div>
                )}

                <div className="flex items-center gap-2">
                  <button
                    onClick={() => onAddToCart(service)}
                    id={`add-service-${service.id}`}
                    className={`flex-1 py-2 px-3 rounded-lg font-bold text-xs transition-all flex items-center justify-center gap-2 ${
                      isJustAdded
                        ? 'bg-emerald-500 text-black'
                        : 'bg-white text-black hover:bg-amber-500 transition-colors shadow-md'
                    }`}
                  >
                    {isJustAdded ? (
                      <>
                        <Check className="w-3.5 h-3.5" />
                        <span>{t.addedToCart}</span>
                      </>
                    ) : (
                      <>
                        <ShoppingCart className="w-3.5 h-3.5" />
                        <span>{t.addToOrder}</span>
                      </>
                    )}
                  </button>

                  <button
                    onClick={() => setSelectedService(service)}
                    className="p-2 rounded-lg bg-white/5 border border-white/10 text-gray-300 hover:text-amber-500 hover:bg-white/10 transition-all"
                    title="تخصيص الطلب أو إضافة ملاحظات"
                  >
                    <Info className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Brief Customization Modal */}
      {selectedService && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-4">
          <div className="glass-card rounded-2xl max-w-md w-full p-6 border-2 border-amber-500/40 space-y-5 relative">
            <div className="flex justify-between items-center border-b border-amber-500/20 pb-3">
              <h3 className="text-lg font-bold text-amber-300 flex items-center gap-2">
                <span>{selectedService.emoji}</span>
                <span>{selectedService.name}</span>
              </h3>
              <button
                onClick={() => setSelectedService(null)}
                className="text-gray-400 hover:text-white text-xl"
              >
                ✕
              </button>
            </div>

            <p className="text-xs text-gray-300">
              {selectedService.description}
            </p>

            <div className="space-y-2">
              <label className="text-xs font-semibold text-amber-200 block text-right">
                تفاصيل وملاحظات الطلب (اسم البراند، الألوان المفضلة، إلخ):
              </label>
              <textarea
                value={customBrief}
                onChange={(e) => setCustomBrief(e.target.value)}
                rows={3}
                placeholder="أدخل الملاحظات التي تود إطلاع المصمم عليها..."
                className="w-full bg-[#0a0b10] border border-amber-500/30 rounded-xl p-3 text-xs text-white placeholder-gray-500 focus:outline-none focus:border-amber-400 text-right"
              />
            </div>

            <div className="flex justify-between items-center pt-2">
              <span className="text-xl font-bold text-gold-gradient font-serif">
                {getPrice(selectedService.priceSAR)}
              </span>
              <button
                onClick={() => handleAddClick(selectedService)}
                className="px-6 py-2.5 rounded-xl bg-gradient-to-r from-amber-400 to-amber-600 text-black font-extrabold text-xs hover:from-amber-300 hover:to-amber-500"
              >
                {t.addToOrder}
              </button>
            </div>
          </div>
        </div>
      )}
    </section>
  );
};
