'use client';

import React from 'react';
import { Language } from '@/types/store';
import { translations } from '@/lib/i18n';
import { Sparkles, Heart } from 'lucide-react';

interface FooterProps {
  language: Language;
  storeName: string;
}

export const Footer: React.FC<FooterProps> = ({ language, storeName }) => {
  const t = translations[language];

  return (
    <footer className="w-full bg-[#080808] border-t border-white/10 py-12 px-4 relative mt-20">
      <div className="max-w-7xl mx-auto grid grid-cols-1 md:grid-cols-4 gap-8 mb-8 text-right">
        {/* Brand Column */}
        <div className="space-y-4 md:col-span-2">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-lg bg-amber-500 text-black font-serif font-black flex items-center justify-center text-lg">
              M
            </div>
            <div>
              <span className="font-serif font-bold text-base tracking-wider text-white uppercase">
                MAESTRO
              </span>
              <p className="text-[9px] tracking-widest text-amber-500 font-sans uppercase">
                Design Studio
              </p>
            </div>
          </div>

          <p className="text-gray-400 text-xs leading-relaxed max-w-md">
            استوديو مايسترو متجر فاخر متوافق مع أحدث معايير الهوية البصرية والتصميم الرقمي. نحول رؤية عملائنا إلى هوية بصرية ملكية لا تُنسى.
          </p>
        </div>

        {/* Quick Links */}
        <div className="space-y-3">
          <h4 className="text-xs font-bold text-white">روابط سريعة</h4>
          <ul className="space-y-2 text-xs text-gray-400">
            <li>
              <a href="#hero" className="hover:text-amber-500 transition-colors">
                {t.navHome}
              </a>
            </li>
            <li>
              <a href="#services" className="hover:text-amber-500 transition-colors">
                {t.navServices}
              </a>
            </li>
            <li>
              <a href="#portfolio" className="hover:text-amber-500 transition-colors">
                {t.navPortfolio}
              </a>
            </li>
            <li>
              <a href="#coupons" className="hover:text-amber-500 transition-colors">
                {t.navCoupons}
              </a>
            </li>
          </ul>
        </div>

        {/* Guarantees */}
        <div className="space-y-3">
          <h4 className="text-xs font-bold text-white">ضمانات مايسترو</h4>
          <ul className="space-y-2 text-xs text-gray-400">
            <li>✨ تسليم الملفات المصدرية بالكامل</li>
            <li>✨ تعديلات غير محدودة حتى الرضا</li>
            <li>✨ حماية حقوق العلامة التجارية</li>
            <li>✨ دعم فني متواصل عبر واتساب</li>
          </ul>
        </div>
      </div>

      {/* Bottom Bar */}
      <div className="max-w-7xl mx-auto pt-6 border-t border-white/5 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-gray-500">
        <span>{t.copyright}</span>
        <div className="flex items-center gap-2">
          <span>صُنِع بـ</span>
          <Heart className="w-3.5 h-3.5 text-amber-500 fill-amber-500" />
          <span>في المملكة العربية السعودية 🇸🇦</span>
        </div>
      </div>
    </footer>
  );
};
