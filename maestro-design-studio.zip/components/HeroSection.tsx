'use client';

import React from 'react';
import { Language } from '@/types/store';
import { translations } from '@/lib/i18n';
import { Sparkles, MessageCircle, ArrowLeft, ArrowRight, ShieldCheck, Award, Zap } from 'lucide-react';

interface HeroSectionProps {
  language: Language;
  whatsappNumber: string;
  onBrowseClick: () => void;
}

export const HeroSection: React.FC<HeroSectionProps> = ({
  language,
  whatsappNumber,
  onBrowseClick,
}) => {
  const t = translations[language];
  const isRtl = language === 'ar';

  const handleWhatsappClick = () => {
    const cleanNum = whatsappNumber.replace(/[^0-9]/g, '');
    const message = encodeURIComponent(
      language === 'ar'
        ? 'مرحباً استوديو مايسترو، أرغب في الاستفسار عن تصاميم الهوية البصرية'
        : 'Hello Maestro Studio, I would like to inquire about brand identity designs.'
    );
    window.open(`https://wa.me/${cleanNum}?text=${message}`, '_blank');
  };

  return (
    <section id="hero" className="relative min-h-[85vh] flex items-center justify-center pt-8 pb-16 px-4 overflow-hidden">
      {/* Ambient Luxury Background Lights */}
      <div className="absolute top-1/4 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[500px] h-[500px] bg-amber-500/10 blur-[140px] rounded-full pointer-events-none" />
      <div className="absolute top-1/3 right-10 w-[300px] h-[300px] bg-yellow-600/10 blur-[100px] rounded-full pointer-events-none" />

      <div className="max-w-7xl mx-auto w-full grid grid-cols-1 lg:grid-cols-12 gap-12 items-center relative z-10">
        {/* Left/Main Column - Texts & CTAs */}
        <div className="lg:col-span-7 text-right flex flex-col items-start gap-6">
          {/* Badge */}
          <div className="inline-flex items-center gap-2.5 px-4 py-2 rounded-full bg-white/5 border border-white/10 text-amber-500 text-xs sm:text-sm font-semibold shadow-lg">
            <Sparkles className="w-4 h-4 text-amber-500" />
            <span>{t.heroBadge}</span>
          </div>

          {/* Headline */}
          <h1 className="text-4xl sm:text-6xl xl:text-7xl font-serif italic mb-2 leading-tight text-white tracking-tight">
            صناعة الهوية البصرية <span className="text-amber-500">بإتقان</span>
          </h1>

          {/* Subtitle */}
          <p className="text-sm sm:text-base text-[#E4E4E4]/70 leading-relaxed font-light max-w-2xl">
            {t.heroDesc}
          </p>

          {/* Action CTAs */}
          <div className="flex flex-wrap items-center gap-4 pt-2 w-full sm:w-auto">
            <button
              onClick={onBrowseClick}
              id="hero-browse-services"
              className="w-full sm:w-auto px-8 py-4 rounded-xl bg-amber-500 text-black font-extrabold text-base hover:bg-amber-400 transition-all shadow-xl shadow-amber-500/10 flex items-center justify-center gap-3 cursor-pointer"
            >
              <span>{t.browseServices}</span>
              {isRtl ? <ArrowLeft className="w-5 h-5" /> : <ArrowRight className="w-5 h-5" />}
            </button>

            <button
              onClick={handleWhatsappClick}
              id="hero-whatsapp-contact"
              className="w-full sm:w-auto px-8 py-4 rounded-xl bg-white/5 border border-white/10 text-emerald-400 hover:text-emerald-300 hover:bg-white/10 font-bold text-base transition-all flex items-center justify-center gap-3 cursor-pointer"
            >
              <MessageCircle className="w-5 h-5 text-emerald-400" />
              <span>{t.contactWhatsapp}</span>
            </button>
          </div>

          {/* Key Value Props Bar */}
          <div className="grid grid-cols-3 gap-4 pt-8 border-t border-white/10 w-full max-w-xl text-right">
            <div className="flex flex-col">
              <span className="text-2xl sm:text-3xl font-black text-amber-500 font-serif italic">+500</span>
              <span className="text-xs text-gray-400 mt-1">هوية بصرية مصممة</span>
            </div>
            <div className="flex flex-col">
              <span className="text-2xl sm:text-3xl font-black text-amber-500 font-serif italic">100%</span>
              <span className="text-xs text-gray-400 mt-1">جودة وسرعة إنجاز</span>
            </div>
            <div className="flex flex-col">
              <span className="text-2xl sm:text-3xl font-black text-amber-500 font-serif italic">24/7</span>
              <span className="text-xs text-gray-400 mt-1">دعم فني وتعديلات</span>
            </div>
          </div>
        </div>

        {/* Right Column - Interactive Luxury Brand Showcase Card */}
        <div className="lg:col-span-5 relative flex justify-center">
          <div className="relative w-full max-w-md bg-white/5 border border-white/10 rounded-2xl p-6 shadow-2xl space-y-6 transform hover:-rotate-1 transition-transform duration-500">
            {/* Header Badge in Card */}
            <div className="flex justify-between items-center border-b border-white/10 pb-4">
              <div className="flex items-center gap-2">
                <div className="w-3 h-3 rounded-full bg-red-500/80" />
                <div className="w-3 h-3 rounded-full bg-yellow-500/80" />
                <div className="w-3 h-3 rounded-full bg-green-500/80" />
              </div>
              <span className="text-xs font-mono text-amber-500 tracking-widest uppercase">
                MAESTRO BRAND KIT
              </span>
            </div>

            {/* Visual Emblem Mockup */}
            <div className="h-48 rounded-xl bg-[#0A0A0A] border border-white/10 flex flex-col items-center justify-center relative overflow-hidden group">
              <div className="w-20 h-20 rounded-2xl bg-amber-500 p-0.5 shadow-2xl group-hover:scale-110 transition-transform">
                <div className="w-full h-full bg-[#080808] rounded-[14px] flex items-center justify-center">
                  <span className="font-serif italic text-4xl font-black text-amber-500">M</span>
                </div>
              </div>
              <span className="mt-3 font-serif italic text-amber-500 tracking-widest text-sm font-bold uppercase">
                Maestro Designs
              </span>
              <span className="text-[10px] text-gray-400 font-sans tracking-widest uppercase">
                PREMIUM VISUAL SYSTEMS
              </span>
            </div>

            {/* Colors & Features List */}
            <div className="space-y-3 text-xs text-gray-300">
              <div className="flex justify-between items-center bg-black/40 p-2.5 rounded-lg border border-white/10">
                <span className="text-gray-400">لوحة الألوان الملكية:</span>
                <div className="flex items-center gap-1.5">
                  <div className="w-4 h-4 rounded-full bg-[#080808] border border-white/20" />
                  <div className="w-4 h-4 rounded-full bg-[#f59e0b]" />
                  <div className="w-4 h-4 rounded-full bg-[#1c1d22]" />
                  <div className="w-4 h-4 rounded-full bg-[#e4e4e4]" />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-2 text-gray-300 font-medium">
                <div className="flex items-center gap-1.5">
                  <ShieldCheck className="w-3.5 h-3.5 text-amber-500" />
                  <span>حقوق ملكية كاملة</span>
                </div>
                <div className="flex items-center gap-1.5">
                  <Zap className="w-3.5 h-3.5 text-amber-500" />
                  <span>ملفات مصدرية AI/EPS</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
