'use client';

import React, { useState } from 'react';
import { PortfolioItem, Language } from '@/types/store';
import { translations } from '@/lib/i18n';
import { Sparkles, Eye, ArrowUpRight, Check, ShoppingCart } from 'lucide-react';

interface PortfolioSectionProps {
  portfolio: PortfolioItem[];
  language: Language;
  onOrderSimilar: (portfolioItem: PortfolioItem) => void;
}

export const PortfolioSection: React.FC<PortfolioSectionProps> = ({
  portfolio,
  language,
  onOrderSimilar,
}) => {
  const t = translations[language];
  const [activeCategory, setActiveCategory] = useState<string>('all');
  const [lightboxItem, setLightboxItem] = useState<PortfolioItem | null>(null);

  const categories = [
    { key: 'all', label: t.filterAll },
    { key: 'logo', label: t.filterLogo },
    { key: 'identity', label: t.filterIdentity },
    { key: 'social', label: t.filterSocial },
    { key: 'packaging', label: t.filterPackaging },
    { key: 'motion', label: t.filterMotion },
    { key: 'web', label: t.filterWeb },
  ];

  const filteredPortfolio =
    activeCategory === 'all'
      ? portfolio
      : portfolio.filter((item) => item.categoryKey === activeCategory);

  return (
    <section id="portfolio" className="py-20 px-4 max-w-7xl mx-auto relative">
      {/* Header */}
      <div className="text-center max-w-3xl mx-auto mb-12 space-y-4">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white/5 border border-white/10 text-amber-500 text-xs font-semibold">
          <Sparkles className="w-3.5 h-3.5 text-amber-500" />
          <span>{t.portfolioTitle}</span>
        </div>
        <h2 className="text-3xl sm:text-5xl font-serif italic text-white tracking-tight">
          معرض <span className="text-amber-500">الأعمال الإبداعية</span>
        </h2>
        <p className="text-gray-400 text-sm sm:text-base">
          {t.portfolioSubtitle}
        </p>
      </div>

      {/* Filter Tabs */}
      <div className="flex flex-wrap items-center justify-center gap-2 mb-12">
        {categories.map((cat) => (
          <button
            key={cat.key}
            onClick={() => setActiveCategory(cat.key)}
            className={`px-4 py-2 rounded-lg text-xs font-medium transition-all ${
              activeCategory === cat.key
                ? 'bg-amber-500 text-black font-bold shadow-md'
                : 'bg-white/5 border border-white/10 text-gray-300 hover:text-amber-500 hover:bg-white/10'
            }`}
          >
            {cat.label}
          </button>
        ))}
      </div>

      {/* Portfolio Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredPortfolio.map((item) => {
          const title =
            language === 'en' && item.titleEn
              ? item.titleEn
              : language === 'fr' && item.titleFr
              ? item.titleFr
              : item.title;

          return (
            <div
              key={item.id}
              className="group bg-white/5 border border-white/5 rounded-xl overflow-hidden hover:bg-white/10 transition-all flex flex-col justify-between"
            >
              {/* Image Container with Hover overlay */}
              <div className="relative aspect-[4/3] overflow-hidden bg-black/60 cursor-pointer" onClick={() => setLightboxItem(item)}>
                <img
                  src={item.image}
                  alt={title}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                  loading="lazy"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/30 to-transparent opacity-60 group-hover:opacity-80 transition-opacity" />

                {/* Badge Category */}
                <div className="absolute top-3 right-3 px-3 py-1 rounded-full bg-black/70 backdrop-blur-md border border-white/10 text-amber-500 text-[10px] font-bold">
                  {item.category}
                </div>

                {/* Quick Eye Button */}
                <div className="absolute bottom-3 left-3 w-9 h-9 rounded-full bg-amber-500 text-black flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity shadow-lg">
                  <Eye className="w-4 h-4" />
                </div>
              </div>

              {/* Text Info */}
              <div className="p-5 flex-1 flex flex-col justify-between space-y-4">
                <div>
                  <h3 className="text-base font-semibold text-white group-hover:text-amber-500 transition-colors">
                    {title}
                  </h3>
                  {item.description && (
                    <p className="text-gray-400 text-xs mt-1.5 line-clamp-2">
                      {item.description}
                    </p>
                  )}
                </div>

                <div className="pt-3 border-t border-white/5 flex items-center justify-between">
                  {item.tags && (
                    <div className="flex flex-wrap gap-1">
                      {item.tags.map((tag, idx) => (
                        <span
                          key={idx}
                          className="text-[10px] px-2 py-0.5 rounded bg-white/5 text-gray-400 border border-white/5"
                        >
                          #{tag}
                        </span>
                      ))}
                    </div>
                  )}

                  <button
                    onClick={() => onOrderSimilar(item)}
                    id={`order-similar-${item.id}`}
                    className="px-3 py-1.5 rounded-lg bg-white text-black hover:bg-amber-500 transition-colors text-xs font-bold flex items-center gap-1.5 shadow-sm"
                  >
                    <ShoppingCart className="w-3.5 h-3.5" />
                    <span>{t.orderSimilar}</span>
                  </button>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Lightbox Modal */}
      {lightboxItem && (
        <div className="fixed inset-0 z-50 bg-black/90 backdrop-blur-lg flex items-center justify-center p-4">
          <div className="glass-card rounded-2xl max-w-3xl w-full overflow-hidden border-2 border-amber-500/40 relative space-y-4 p-6">
            <button
              onClick={() => setLightboxItem(null)}
              className="absolute top-4 left-4 z-10 w-8 h-8 rounded-full bg-black/60 text-white flex items-center justify-center hover:bg-amber-500 hover:text-black transition-colors"
            >
              ✕
            </button>

            <div className="rounded-xl overflow-hidden max-h-[60vh]">
              <img
                src={lightboxItem.image}
                alt={lightboxItem.title}
                className="w-full h-full object-contain bg-black"
              />
            </div>

            <div className="space-y-2 text-right">
              <span className="text-xs font-semibold text-amber-400">
                {lightboxItem.category}
              </span>
              <h3 className="text-2xl font-bold text-white">
                {lightboxItem.title}
              </h3>
              {lightboxItem.description && (
                <p className="text-gray-300 text-sm">
                  {lightboxItem.description}
                </p>
              )}
            </div>

            <div className="flex justify-end pt-3 border-t border-amber-500/20">
              <button
                onClick={() => {
                  onOrderSimilar(lightboxItem);
                  setLightboxItem(null);
                }}
                className="px-6 py-3 rounded-xl bg-gradient-to-r from-amber-400 to-amber-600 text-black font-extrabold text-sm flex items-center gap-2"
              >
                <ShoppingCart className="w-4 h-4" />
                <span>{t.orderSimilar}</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </section>
  );
};
