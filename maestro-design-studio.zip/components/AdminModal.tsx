'use client';

import React, { useState } from 'react';
import {
  ServiceItem,
  PortfolioItem,
  Coupon,
  StoreSettings,
  Language,
  OrderRecord,
} from '@/types/store';
import { translations } from '@/lib/i18n';
import {
  Lock,
  Plus,
  Trash2,
  Edit2,
  Image as ImageIcon,
  Ticket,
  Settings,
  X,
  Check,
  ShieldAlert,
  BarChart2,
  Save,
  KeyRound,
  ShoppingBag,
  CheckCircle,
  MessageCircle,
  Clock,
  Send,
  User,
  Phone,
  FileText,
} from 'lucide-react';

interface AdminModalProps {
  isOpen: boolean;
  onClose: () => void;
  services: ServiceItem[];
  portfolio: PortfolioItem[];
  coupons: Coupon[];
  settings: StoreSettings;
  language: Language;
  orders?: OrderRecord[];
  onUpdateServices: (services: ServiceItem[]) => void;
  onUpdatePortfolio: (portfolio: PortfolioItem[]) => void;
  onUpdateCoupons: (coupons: Coupon[]) => void;
  onUpdateSettings: (settings: StoreSettings) => void;
  onUpdateOrders?: (orders: OrderRecord[]) => void;
}

export const AdminModal: React.FC<AdminModalProps> = ({
  isOpen,
  onClose,
  services,
  portfolio,
  coupons,
  settings,
  language,
  orders = [],
  onUpdateServices,
  onUpdatePortfolio,
  onUpdateCoupons,
  onUpdateSettings,
  onUpdateOrders,
}) => {
  const t = translations[language];

  const [pinInput, setPinInput] = useState('');
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [authError, setAuthError] = useState('');
  const [activeTab, setActiveTab] = useState<
    'orders' | 'services' | 'portfolio' | 'coupons' | 'settings'
  >('orders');

  // New Service state
  const [newServiceName, setNewServiceName] = useState('');
  const [newServiceDesc, setNewServiceDesc] = useState('');
  const [newServicePrice, setNewServicePrice] = useState('200');
  const [newServiceEmoji, setNewServiceEmoji] = useState('✨');
  const [newServiceCategory, setNewServiceCategory] = useState<
    'logo' | 'social' | 'identity' | 'motion' | 'packaging' | 'web' | 'other'
  >('logo');

  // Editing service state
  const [editingServiceId, setEditingServiceId] = useState<string | null>(null);

  // New Portfolio state
  const [newPortTitle, setNewPortTitle] = useState('');
  const [newPortImage, setNewPortImage] = useState('');
  const [newPortCategory, setNewPortCategory] = useState('Logo Design');

  // New Coupon state
  const [newCouponCode, setNewCouponCode] = useState('');
  const [newCouponDiscount, setNewCouponDiscount] = useState('15');

  // Settings form state
  const [formSettings, setFormSettings] = useState<StoreSettings>({ ...settings });
  const [settingsSuccess, setSettingsSuccess] = useState('');

  if (!isOpen) return null;

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (pinInput.trim() === settings.adminPin.trim()) {
      setIsAuthenticated(true);
      setAuthError('');
    } else {
      setAuthError(t.incorrectPin);
    }
  };

  // Service CRUD
  const handleAddService = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newServiceName.trim()) return;

    const newService: ServiceItem = {
      id: `srv-${Date.now()}`,
      name: newServiceName,
      description: newServiceDesc,
      priceSAR: Number(newServicePrice) || 100,
      emoji: newServiceEmoji || '🎨',
      category: newServiceCategory,
      popular: false,
      deliveryDays: 3,
    };

    onUpdateServices([...services, newService]);
    setNewServiceName('');
    setNewServiceDesc('');
  };

  const handleDeleteService = (id: string) => {
    onUpdateServices(services.filter((s) => s.id !== id));
  };

  // Portfolio CRUD
  const handleAddPortfolio = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newPortTitle.trim() || !newPortImage.trim()) return;

    const newItem: PortfolioItem = {
      id: `port-${Date.now()}`,
      title: newPortTitle,
      category: newPortCategory,
      categoryKey: 'logo',
      image: newPortImage,
      description: 'تصميم جديد مضاف حديثاً لمعرض الأعمال',
    };

    onUpdatePortfolio([...portfolio, newItem]);
    setNewPortTitle('');
    setNewPortImage('');
  };

  const handleDeletePortfolio = (id: string) => {
    onUpdatePortfolio(portfolio.filter((p) => p.id !== id));
  };

  // Coupon CRUD
  const handleAddCoupon = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newCouponCode.trim()) return;

    const codeClean = newCouponCode.trim().toUpperCase();
    const newC: Coupon = {
      code: codeClean,
      discountPercent: Number(newCouponDiscount) || 10,
      active: true,
      usesCount: 0,
    };

    onUpdateCoupons([...coupons.filter((c) => c.code !== codeClean), newC]);
    setNewCouponCode('');
  };

  const handleDeleteCoupon = (code: string) => {
    onUpdateCoupons(coupons.filter((c) => c.code !== code));
  };

  const handleToggleCouponActive = (code: string) => {
    onUpdateCoupons(
      coupons.map((c) => (c.code === code ? { ...c, active: !c.active } : c))
    );
  };

  // Settings Save
  const handleSaveSettings = (e: React.FormEvent) => {
    e.preventDefault();
    onUpdateSettings(formSettings);
    setSettingsSuccess(t.settingsSaved);
    setTimeout(() => setSettingsSuccess(''), 2500);
  };

  // Orders Management Handlers
  const handleApproveOrder = (orderId: string) => {
    if (!onUpdateOrders) return;
    const updated = orders.map((o) =>
      o.id === orderId ? { ...o, status: 'in_progress' as const } : o
    );
    onUpdateOrders(updated);
  };

  const handleCompleteOrderAndNotify = (order: OrderRecord) => {
    if (!onUpdateOrders) return;
    const updated = orders.map((o) =>
      o.id === order.id ? { ...o, status: 'completed' as const } : o
    );
    onUpdateOrders(updated);

    // Send notification to WhatsApp
    const cleanPhone = order.clientPhone.replace(/[^0-9]/g, '');
    const storeName = settings.storeName || 'استوديو مايسترو';
    let text = `مرحباً ${order.clientName} 👋\n\n`;
    text += `يسعدنا إبلاغك بأن طلبك لدى *${storeName}* (رقم الطلب: ${order.id}) قد اكتمل بنجاح وهو جاهز الآن! 🎉✅\n\n`;
    text += `📋 *تفاصيل الطلب:*\n`;
    order.items.forEach((item, index) => {
      text += `${index + 1}. ${item.service.name} (الكمية: ${item.quantity})\n`;
    });
    text += `\n💰 *المجموع النهائي:* ${order.totalSAR} ر.س\n\nنشكرك على ثقتك بنا ونسعد بخدمتك دائماً! ❤️`;

    window.open(`https://wa.me/${cleanPhone}?text=${encodeURIComponent(text)}`, '_blank');
  };

  const handleDeleteOrder = (orderId: string) => {
    if (!onUpdateOrders) return;
    const updated = orders.filter((o) => o.id !== orderId);
    onUpdateOrders(updated);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/90 backdrop-blur-lg flex items-center justify-center p-4">
      <div className="bg-[#0A0A0A] rounded-2xl max-w-4xl w-full max-h-[90vh] overflow-hidden border border-white/10 relative flex flex-col">
        {/* Header Bar */}
        <div className="p-6 border-b border-white/10 flex items-center justify-between bg-[#080808]">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-lg bg-white/5 border border-white/10 flex items-center justify-center text-amber-500">
              <Lock className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-lg font-serif italic text-white">{t.adminTitle}</h2>
              <span className="text-[10px] text-amber-500 font-mono">
                Maestro Control System v2.0
              </span>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 rounded-lg text-gray-400 hover:text-white hover:bg-white/10 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Auth Screen */}
        {!isAuthenticated ? (
          <div className="p-8 sm:p-12 text-center my-auto max-w-md mx-auto space-y-6 w-full">
            <div className="w-14 h-14 rounded-full bg-white/5 border border-white/10 flex items-center justify-center text-amber-500 mx-auto">
              <KeyRound className="w-6 h-6" />
            </div>

            <div className="space-y-2">
              <h3 className="text-lg font-serif italic text-white">{t.enterPinTitle}</h3>
              <p className="text-xs text-gray-400">
                أدخل الرمز السري للوصول للوحة الإدارة (الرمز الافتراضي: 22768061)
              </p>
            </div>

            <form onSubmit={handleLogin} className="space-y-4">
              <input
                type="password"
                value={pinInput}
                onChange={(e) => {
                  setPinInput(e.target.value);
                  setAuthError('');
                }}
                placeholder={t.enterPinPlaceholder}
                className="w-full bg-black/40 border border-white/10 rounded-lg p-3 text-center text-base font-mono tracking-widest text-white focus:outline-none focus:border-amber-500"
              />

              {authError && (
                <p className="text-xs text-rose-400 font-bold flex items-center justify-center gap-1">
                  <ShieldAlert className="w-4 h-4" />
                  <span>{authError}</span>
                </p>
              )}

              <button
                type="submit"
                className="w-full py-3 rounded-lg bg-amber-500 text-black font-bold text-xs hover:bg-amber-400 transition-all shadow-md"
              >
                {t.loginAdmin}
              </button>
            </form>
          </div>
        ) : (
          /* Authenticated Dashboard Body */
          <div className="flex-1 overflow-y-auto flex flex-col">
            {/* Tabs Bar */}
            <div className="flex flex-wrap items-center gap-2 p-4 bg-[#080808] border-b border-white/10">
              <button
                onClick={() => setActiveTab('orders')}
                className={`px-4 py-2 rounded-lg text-xs font-semibold flex items-center gap-2 transition-all relative ${
                  activeTab === 'orders'
                    ? 'bg-amber-500 text-black shadow-md'
                    : 'bg-white/5 text-gray-300 hover:text-white hover:bg-white/10'
                }`}
              >
                <ShoppingBag className="w-3.5 h-3.5" />
                <span>طلبات العملاء</span>
                {orders.length > 0 && (
                  <span
                    className={`px-1.5 py-0.5 text-[10px] font-bold rounded-full ${
                      activeTab === 'orders'
                        ? 'bg-black text-amber-400'
                        : 'bg-amber-500 text-black'
                    }`}
                  >
                    {orders.length}
                  </span>
                )}
              </button>

              <button
                onClick={() => setActiveTab('services')}
                className={`px-4 py-2 rounded-lg text-xs font-semibold flex items-center gap-2 transition-all ${
                  activeTab === 'services'
                    ? 'bg-amber-500 text-black shadow-md'
                    : 'bg-white/5 text-gray-300 hover:text-white hover:bg-white/10'
                }`}
              >
                <Plus className="w-3.5 h-3.5" />
                <span>الخدمات والأسعار</span>
              </button>

              <button
                onClick={() => setActiveTab('portfolio')}
                className={`px-4 py-2 rounded-lg text-xs font-semibold flex items-center gap-2 transition-all ${
                  activeTab === 'portfolio'
                    ? 'bg-amber-500 text-black shadow-md'
                    : 'bg-white/5 text-gray-300 hover:text-white hover:bg-white/10'
                }`}
              >
                <ImageIcon className="w-3.5 h-3.5" />
                <span>معرض الأعمال</span>
              </button>

              <button
                onClick={() => setActiveTab('coupons')}
                className={`px-4 py-2 rounded-lg text-xs font-semibold flex items-center gap-2 transition-all ${
                  activeTab === 'coupons'
                    ? 'bg-amber-500 text-black shadow-md'
                    : 'bg-white/5 text-gray-300 hover:text-white hover:bg-white/10'
                }`}
              >
                <Ticket className="w-3.5 h-3.5" />
                <span>إدارة الكوبونات</span>
              </button>

              <button
                onClick={() => setActiveTab('settings')}
                className={`px-4 py-2 rounded-lg text-xs font-semibold flex items-center gap-2 transition-all ${
                  activeTab === 'settings'
                    ? 'bg-amber-500 text-black shadow-md'
                    : 'bg-white/5 text-gray-300 hover:text-white hover:bg-white/10'
                }`}
              >
                <Settings className="w-3.5 h-3.5" />
                <span>{t.storeSettings}</span>
              </button>
            </div>

            {/* Tab Contents */}
            <div className="p-6 space-y-8 flex-1 overflow-y-auto">
              {/* ORDERS TAB */}
              {activeTab === 'orders' && (
                <div className="space-y-6 text-right">
                  <div className="flex items-center justify-between border-b border-white/10 pb-3">
                    <h3 className="text-sm font-bold text-white flex items-center gap-2">
                      <ShoppingBag className="w-4 h-4 text-amber-500" />
                      <span>قائمة طلبات العملاء ({orders.length})</span>
                    </h3>
                    <span className="text-xs text-gray-400">
                      تابع الطلبات، وافق عليها، ثم أرسل إشعار جاهزية للعميل مباشرة على الواتساب 💬
                    </span>
                  </div>

                  {orders.length === 0 ? (
                    <div className="py-12 text-center text-gray-400 bg-white/5 rounded-2xl border border-white/5 space-y-2">
                      <div className="text-3xl">📥</div>
                      <p className="text-xs">لا يوجد أي طلبات حتى الآن</p>
                    </div>
                  ) : (
                    <div className="space-y-4">
                      {orders.map((order) => (
                        <div
                          key={order.id}
                          className="bg-white/5 rounded-2xl p-5 border border-white/10 space-y-4 hover:border-amber-500/30 transition-all"
                        >
                          {/* Order Header */}
                          <div className="flex flex-wrap items-center justify-between gap-3 border-b border-white/5 pb-3">
                            <div className="flex items-center gap-2">
                              <span className="font-mono text-xs font-bold text-amber-500 bg-amber-500/10 px-2.5 py-1 rounded-md border border-amber-500/20">
                                {order.id}
                              </span>
                              <span className="text-[11px] text-gray-400 font-mono">
                                {order.createdAt}
                              </span>
                            </div>

                            {/* Status Badge */}
                            <div>
                              {order.status === 'pending' && (
                                <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-amber-500/10 border border-amber-500/30 text-amber-400 text-xs font-bold">
                                  <Clock className="w-3.5 h-3.5" />
                                  <span>جديد (قيد الانتظار)</span>
                                </span>
                              )}
                              {order.status === 'in_progress' && (
                                <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-blue-500/10 border border-blue-500/30 text-blue-400 text-xs font-bold">
                                  <Send className="w-3.5 h-3.5" />
                                  <span>تمت الموافقة / جاري العمل</span>
                                </span>
                              )}
                              {order.status === 'completed' && (
                                <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 text-xs font-bold">
                                  <CheckCircle className="w-3.5 h-3.5" />
                                  <span>مكتمل وجاهز ✓</span>
                                </span>
                              )}
                            </div>
                          </div>

                          {/* Client Information */}
                          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 bg-black/30 p-3.5 rounded-xl border border-white/5 text-xs">
                            <div className="flex items-center gap-2">
                              <User className="w-3.5 h-3.5 text-amber-500 shrink-0" />
                              <span className="text-gray-400">العميل:</span>
                              <strong className="text-white">{order.clientName}</strong>
                            </div>
                            <div className="flex items-center gap-2">
                              <Phone className="w-3.5 h-3.5 text-amber-500 shrink-0" />
                              <span className="text-gray-400">رقم التواصل:</span>
                              <strong className="text-amber-400 font-mono dir-ltr">{order.clientPhone}</strong>
                            </div>
                            {order.projectNotes && (
                              <div className="sm:col-span-2 flex items-start gap-2 pt-2 border-t border-white/5">
                                <FileText className="w-3.5 h-3.5 text-amber-500 shrink-0 mt-0.5" />
                                <span className="text-gray-400">ملاحظات / البراند:</span>
                                <p className="text-white italic">{order.projectNotes}</p>
                              </div>
                            )}
                          </div>

                          {/* Items Ordered */}
                          <div className="space-y-2">
                            <span className="text-[11px] font-bold text-gray-300 block">الخدمات المطلوبة:</span>
                            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                              {order.items.map((item, idx) => (
                                <div
                                  key={idx}
                                  className="flex items-center justify-between p-2.5 rounded-lg bg-white/5 border border-white/5 text-xs"
                                >
                                  <div className="flex items-center gap-2">
                                    <span>{item.service.emoji}</span>
                                    <span className="font-semibold text-white">{item.service.name}</span>
                                    <span className="text-gray-400">× {item.quantity}</span>
                                  </div>
                                  <span className="font-mono text-amber-500 font-bold">
                                    {item.service.priceSAR * item.quantity} ر.س
                                  </span>
                                </div>
                              ))}
                            </div>
                            <div className="flex justify-between items-center pt-2 text-xs font-bold text-white">
                              <span>المجموع الكلي:</span>
                              <span className="text-sm font-mono text-amber-500">{order.totalSAR} ر.س</span>
                            </div>
                          </div>

                          {/* Status Actions */}
                          <div className="flex flex-wrap items-center justify-end gap-2 pt-3 border-t border-white/10">
                            {order.status !== 'in_progress' && order.status !== 'completed' && (
                              <button
                                onClick={() => handleApproveOrder(order.id)}
                                className="px-3.5 py-2 rounded-lg bg-blue-600/20 border border-blue-500/40 text-blue-300 hover:bg-blue-600 hover:text-white text-xs font-bold transition-all flex items-center gap-1.5"
                              >
                                <span>موافقة على الخدمة 👍</span>
                              </button>
                            )}

                            <button
                              onClick={() => handleCompleteOrderAndNotify(order)}
                              className="px-4 py-2 rounded-lg bg-emerald-600 text-white font-bold text-xs hover:bg-emerald-500 transition-all flex items-center gap-1.5 shadow-md"
                            >
                              <CheckCircle className="w-3.5 h-3.5" />
                              <span>علامة ✓ تم الإنجاز وإرسال رسالة واتساب للعميل</span>
                            </button>

                            <button
                              onClick={() => handleDeleteOrder(order.id)}
                              className="p-2 text-rose-400/80 hover:text-rose-400 hover:bg-rose-950/40 rounded-lg transition-colors"
                              title="حذف الطلب"
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              )}
              {/* SERVICES TAB */}
              {activeTab === 'services' && (
                <div className="space-y-8 text-right">
                  {/* Add New Service Form */}
                  <div className="p-5 rounded-2xl bg-[#08090f] border border-amber-500/20 space-y-4">
                    <h3 className="text-base font-bold text-amber-300 flex items-center gap-2 justify-end">
                      <span>{t.addNewService}</span>
                      <Plus className="w-4 h-4" />
                    </h3>

                    <form onSubmit={handleAddService} className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <label className="text-xs text-gray-300 block mb-1">{t.serviceName}:</label>
                        <input
                          type="text"
                          value={newServiceName}
                          onChange={(e) => setNewServiceName(e.target.value)}
                          placeholder="مثال: تصميم بروفايل شركة"
                          className="w-full bg-[#0f111a] border border-amber-500/30 rounded-xl p-2.5 text-xs text-white text-right"
                        />
                      </div>

                      <div>
                        <label className="text-xs text-gray-300 block mb-1">{t.servicePriceSAR}:</label>
                        <input
                          type="number"
                          value={newServicePrice}
                          onChange={(e) => setNewServicePrice(e.target.value)}
                          className="w-full bg-[#0f111a] border border-amber-500/30 rounded-xl p-2.5 text-xs text-white text-right font-mono"
                        />
                      </div>

                      <div>
                        <label className="text-xs text-gray-300 block mb-1">{t.serviceEmoji}:</label>
                        <input
                          type="text"
                          value={newServiceEmoji}
                          onChange={(e) => setNewServiceEmoji(e.target.value)}
                          className="w-full bg-[#0f111a] border border-amber-500/30 rounded-xl p-2.5 text-xs text-white text-center"
                        />
                      </div>

                      <div>
                        <label className="text-xs text-gray-300 block mb-1">{t.serviceDesc}:</label>
                        <input
                          type="text"
                          value={newServiceDesc}
                          onChange={(e) => setNewServiceDesc(e.target.value)}
                          placeholder="وصف مختصر للخدمة..."
                          className="w-full bg-[#0f111a] border border-amber-500/30 rounded-xl p-2.5 text-xs text-white text-right"
                        />
                      </div>

                      <div className="md:col-span-2 pt-2">
                        <button
                          type="submit"
                          className="px-6 py-2.5 rounded-xl bg-amber-500 text-black font-extrabold text-xs hover:bg-amber-400 transition-colors"
                        >
                          {t.addServiceBtn}
                        </button>
                      </div>
                    </form>
                  </div>

                  {/* Existing Services List */}
                  <div className="space-y-3">
                    <h3 className="text-base font-bold text-white">{t.editExistingServices}:</h3>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      {services.map((service) => (
                        <div
                          key={service.id}
                          className="bg-white/5 rounded-xl p-4 border border-white/10 space-y-3"
                        >
                          <div className="flex items-center justify-between gap-2">
                            <div className="flex items-center gap-2 flex-1">
                              <span className="text-xl">{service.emoji}</span>
                              <input
                                type="text"
                                value={service.name}
                                onChange={(e) => {
                                  const updated = services.map((s) =>
                                    s.id === service.id ? { ...s, name: e.target.value } : s
                                  );
                                  onUpdateServices(updated);
                                }}
                                className="w-full bg-black/40 border border-white/10 rounded-lg px-2 py-1 text-xs font-bold text-white text-right focus:border-amber-500 focus:outline-none"
                              />
                            </div>
                            <button
                              onClick={() => handleDeleteService(service.id)}
                              className="p-1.5 text-rose-400 hover:bg-rose-950/40 rounded-lg transition-colors"
                              title="حذف الخدمة"
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          </div>

                          <div className="flex items-center justify-between gap-3 pt-2 border-t border-white/5">
                            <div className="flex items-center gap-1.5">
                              <span className="text-[11px] text-gray-400">السعر:</span>
                              <input
                                type="number"
                                value={service.priceSAR}
                                onChange={(e) => {
                                  const val = Number(e.target.value) || 0;
                                  const updated = services.map((s) =>
                                    s.id === service.id ? { ...s, priceSAR: val } : s
                                  );
                                  onUpdateServices(updated);
                                }}
                                className="w-20 bg-black/40 border border-white/10 rounded-lg px-2 py-1 text-xs font-mono font-bold text-amber-500 text-right focus:border-amber-500 focus:outline-none"
                              />
                              <span className="text-[10px] text-gray-400">ر.س</span>
                            </div>

                            <div className="flex items-center gap-1.5">
                              <span className="text-[11px] text-gray-400">الإنجاز:</span>
                              <input
                                type="number"
                                value={service.deliveryDays || 1}
                                onChange={(e) => {
                                  const val = Number(e.target.value) || 1;
                                  const updated = services.map((s) =>
                                    s.id === service.id ? { ...s, deliveryDays: val } : s
                                  );
                                  onUpdateServices(updated);
                                }}
                                className="w-14 bg-black/40 border border-white/10 rounded-lg px-2 py-1 text-xs font-mono text-white text-right focus:border-amber-500 focus:outline-none"
                              />
                              <span className="text-[10px] text-gray-400">أيام</span>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              )}

              {/* PORTFOLIO TAB */}
              {activeTab === 'portfolio' && (
                <div className="space-y-8 text-right">
                  <div className="p-5 rounded-2xl bg-[#08090f] border border-amber-500/20 space-y-4">
                    <h3 className="text-base font-bold text-amber-300">{t.addPortfolioImage}</h3>
                    <form onSubmit={handleAddPortfolio} className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <label className="text-xs text-gray-300 block mb-1">{t.imageTitle}:</label>
                        <input
                          type="text"
                          value={newPortTitle}
                          onChange={(e) => setNewPortTitle(e.target.value)}
                          placeholder="عنوان العمل..."
                          className="w-full bg-[#0f111a] border border-amber-500/30 rounded-xl p-2.5 text-xs text-white text-right"
                        />
                      </div>

                      <div>
                        <label className="text-xs text-gray-300 block mb-1">{t.imageUrl}:</label>
                        <input
                          type="url"
                          value={newPortImage}
                          onChange={(e) => setNewPortImage(e.target.value)}
                          placeholder="https://images.unsplash.com/..."
                          className="w-full bg-[#0f111a] border border-amber-500/30 rounded-xl p-2.5 text-xs text-white text-left font-mono"
                        />
                      </div>

                      <div className="md:col-span-2 pt-2">
                        <button
                          type="submit"
                          className="px-6 py-2.5 rounded-xl bg-amber-500 text-black font-extrabold text-xs hover:bg-amber-400"
                        >
                          {t.addToPortfolioBtn}
                        </button>
                      </div>
                    </form>
                  </div>

                  <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                    {portfolio.map((item) => (
                      <div
                        key={item.id}
                        className="glass-card rounded-xl overflow-hidden border border-amber-500/20 relative group"
                      >
                        <img src={item.image} alt={item.title} className="w-full h-32 object-cover" />
                        <div className="p-2 flex justify-between items-center bg-[#07080d]">
                          <span className="text-xs text-white font-bold truncate">{item.title}</span>
                          <button
                            onClick={() => handleDeletePortfolio(item.id)}
                            className="text-rose-400 hover:text-rose-300 p-1"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* COUPONS TAB */}
              {activeTab === 'coupons' && (
                <div className="space-y-8 text-right">
                  <div className="p-5 rounded-2xl bg-[#08090f] border border-amber-500/20 space-y-4">
                    <h3 className="text-base font-bold text-amber-300">{t.manageCoupons}</h3>
                    <form onSubmit={handleAddCoupon} className="flex flex-col sm:flex-row gap-3">
                      <input
                        type="text"
                        value={newCouponCode}
                        onChange={(e) => setNewCouponCode(e.target.value)}
                        placeholder={t.couponCode}
                        className="bg-[#0f111a] border border-amber-500/30 rounded-xl p-2.5 text-xs text-white font-mono uppercase text-right"
                      />
                      <input
                        type="number"
                        value={newCouponDiscount}
                        onChange={(e) => setNewCouponDiscount(e.target.value)}
                        placeholder={t.discountPercent}
                        className="bg-[#0f111a] border border-amber-500/30 rounded-xl p-2.5 text-xs text-white font-mono text-right w-28"
                      />
                      <button
                        type="submit"
                        className="px-6 py-2.5 rounded-xl bg-amber-500 text-black font-extrabold text-xs hover:bg-amber-400"
                      >
                        {t.addCouponBtn}
                      </button>
                    </form>
                  </div>

                  <div className="space-y-2">
                    {coupons.map((c) => (
                      <div
                        key={c.code}
                        className="glass-card rounded-xl p-3 border border-amber-500/20 flex items-center justify-between"
                      >
                        <div className="flex items-center gap-3">
                          <span className="font-mono font-bold text-amber-300 text-sm">{c.code}</span>
                          <span className="text-xs bg-amber-500 text-black px-2 py-0.5 rounded font-bold">
                            {c.discountPercent}% خصم
                          </span>
                          <span className={`text-[10px] px-2 py-0.5 rounded ${c.active ? 'bg-emerald-950 text-emerald-300' : 'bg-gray-800 text-gray-400'}`}>
                            {c.active ? 'مفعل' : 'معطل'}
                          </span>
                        </div>

                        <div className="flex items-center gap-2">
                          <button
                            onClick={() => handleToggleCouponActive(c.code)}
                            className="text-xs text-amber-300 hover:underline"
                          >
                            تغيير الحالة
                          </button>
                          <button
                            onClick={() => handleDeleteCoupon(c.code)}
                            className="p-1.5 text-rose-400 hover:bg-rose-950/40 rounded"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* SETTINGS TAB */}
              {activeTab === 'settings' && (
                <form onSubmit={handleSaveSettings} className="space-y-6 text-right">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label className="text-xs text-gray-300 block mb-1">
                        {t.whatsappNumberLabel}:
                      </label>
                      <input
                        type="text"
                        value={formSettings.whatsappNumber}
                        onChange={(e) =>
                          setFormSettings({ ...formSettings, whatsappNumber: e.target.value })
                        }
                        className="w-full bg-[#0f111a] border border-amber-500/30 rounded-xl p-2.5 text-xs text-white dir-ltr font-mono text-left"
                      />
                    </div>

                    <div>
                      <label className="text-xs text-gray-300 block mb-1">
                        {t.adminPinLabel}:
                      </label>
                      <input
                        type="text"
                        value={formSettings.adminPin}
                        onChange={(e) =>
                          setFormSettings({ ...formSettings, adminPin: e.target.value })
                        }
                        className="w-full bg-[#0f111a] border border-amber-500/30 rounded-xl p-2.5 text-xs text-white font-mono text-right"
                      />
                    </div>

                    <div>
                      <label className="text-xs text-gray-300 block mb-1">
                        {t.storeNameLabel}:
                      </label>
                      <input
                        type="text"
                        value={formSettings.storeName}
                        onChange={(e) =>
                          setFormSettings({ ...formSettings, storeName: e.target.value })
                        }
                        className="w-full bg-[#0f111a] border border-amber-500/30 rounded-xl p-2.5 text-xs text-white text-right"
                      />
                    </div>

                    <div>
                      <label className="text-xs text-gray-300 block mb-1">
                        رقم الآيبان (IBAN):
                      </label>
                      <input
                        type="text"
                        value={formSettings.bankIban}
                        onChange={(e) =>
                          setFormSettings({ ...formSettings, bankIban: e.target.value })
                        }
                        className="w-full bg-[#0f111a] border border-amber-500/30 rounded-xl p-2.5 text-xs text-white font-mono text-right"
                      />
                    </div>
                  </div>

                  {settingsSuccess && (
                    <div className="p-3 rounded-xl bg-emerald-950/60 border border-emerald-500/40 text-emerald-300 text-xs font-bold text-center">
                      {settingsSuccess}
                    </div>
                  )}

                  <button
                    type="submit"
                    className="px-8 py-3 rounded-xl bg-gradient-to-r from-amber-400 to-amber-600 text-black font-extrabold text-xs hover:from-amber-300 hover:to-amber-500 shadow-lg"
                  >
                    {t.saveSettings}
                  </button>
                </form>
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
